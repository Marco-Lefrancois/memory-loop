# 🎤 Présentation Table Ronde AI : L'Ingénierie du « Grill with Docs » & le Passage-Level Grounding

> **Auteur** : Marco Lefrançois & Équipe Architecture mLoop  
> **Audience** : Table Ronde AI & Praticiens IA / Devs / Product Owners  
> **Thème** : *Comment transformer l'IA d'un générateur de texte complaisant en un auditeur d'architecture infaillible, transparent et fondé sur des preuves.*

---

## 🧭 Plan de la Présentation (Pitch Deck 15-20 min)

1. **Le Problème Invisible des Assistants IA Actuels** (Le piège de la complaisance & du RAG passif)
2. **Le Changement de Paradigme : « Faits vs Décisions »** (The Brooks & Pocock Principle)
3. **Le Standard « Dossier de Preuves Documentaires »** (L'Anatomie du Passage-Level Grounding)
4. **Démonstration Concrète : Étude de Cas Réelle** (Projet Boire & Frères — Incubation)
5. **L'Architecture Technique Sous le Capot (ADR-0326)** (Le Système de Preuves en 4 Couches)
6. **Impact Mesuré & Déploiement** (Pourquoi l'équipe « capote » et comment l'adopter)

---

# 🔴 Slide 1 : Le Problème Invisible de l'IA en Entreprise

### Le Syndrome du « *Docile Polisher* » (Complaisance Artificielle / Anti-Sycophancy)

```mermaid
flowchart LR
    subgraph Defaut["❌ L'Approche Naïve (Standard Industrie)"]
        A["Document Brut ou Brouillon"] --> B["IA Générative / RAG Passif"]
        B --> C["Questionnaire Vague (10 questions à puces)"]
        B --> D["Spécification Hallucinée (Fausses APIs, paramètres inventés)"]
    end
```

### Les 3 Failles Majeures du RAG Classique :
1. **L'IA assume au lieu de chercher** : Elle extrapole des règles métiers logiques... mais fausses pour le client.
2. **La fatigue décisionnelle du PO** : L'IA pose des listes interminables de questions triviales dont les réponses sont déjà dans les documents ingérés.
3. **La rupture de confiance** : *« Est-ce que l'IA a vraiment lu notre transcription de 45 minutes et le modèle de données, ou est-ce qu'elle improvise ? »*

> 💡 **Le constat** : L'intelligence d'un modèle ne réside pas dans sa vitesse à répondre, mais dans sa **rigueur à prouver**.

---

# 🟢 Slide 2 : La Philosophie mLoop — « Faits vs Décisions »

Inspiré de **Frederick P. Brooks Jr.** (*The Design of Design*) et des patterns de **Matt Pocock** (*AI Hero*) :

```mermaid
flowchart TD
    subgraph Dual["La Loi de Séparation Épistémique"]
        F["🔍 LES FAITS (Look it up)<br/>Responsabilité 100% IA<br/>- Exploration disque, AST, FTS5<br/>- Interdiction d'interroger l'humain sur ce qui est écrit"]
        D["⚖️ LES DÉCISIONS (Ask the PO)<br/>Responsabilité 100% Humain (PO)<br/>- Arbitrages de valeur et priorités<br/>- 1 seule question à la fois avec recommandation motivée"]
    end
```

### La Règle d'Or de l'Interview :
* **Search-Before-Ask** : Zéro question sans avoir préalablement fouillé les sources et indexé les extraits.
* **Frontier Design Tree** : Une seule question par tour, ordonnancée selon la frontière active de l'arbre de décision.
* **First-Principles Roast** : Déconstruire le besoin à froid sans complaisance avant de raffiner.

---

# 🏆 Slide 3 : L'Anatomie du « Dossier de Preuves Documentaires »

Avant de poser la moindre question d'arbitrage au PO, l'agent génère systématiquement un **Dossier de Preuves Visibles en 4 Blocs** :

````carousel
```markdown
### 1. 🖼️ Maquettes & Notes d'Atelier (SSOT Visuelle)
- Liens physiques cliquables direct : file:///.../maquette.svg
- Mise en évidence des notes de cadrage (ex: ajout de colonnes, filtres)
- Règle d'or : La maquette validée l'emporte toujours sur le texte !
```
<!-- slide -->
```markdown
### 2. 🎙️ Extraits Verbatim Sourcés (Passage-Level Grounding)
Source : docs/00-ingested/.../Atelier.md

> Extrait 1 — Règle de tri (Lignes 301–324) :
> « J'affiche mon troupeau le plus jeune, puis la date la plus vieille... »
> ➔ Fait établi : Tri hiérarchique par âge, puis par date de ponte.
```
<!-- slide -->
```markdown
### 3. 🗄️ Structure de Données & Modèle DBML
- Entités physiques réelles (InventoryLot, HumanReadableId, CurrentlyInBuggy)
- Schéma typé et contraintes de tables
- Statuts de cycle de vie validés
```
<!-- slide -->
```markdown
### 4. ❓ Question d'Arbitrage Unitaire (Option A Recommandée / B / C)
- Mise en situation contextualisée adossée aux faits 1, 2 et 3
- Option A motivée techniquement
- Question fermée de décision (zéro dispersion)
```
````

---

# 🔬 Slide 4 : Étude de Cas Réelle (Projet Boire & Frères — Segment 2)

### Cas concret : Récit `INC-001` (Inventaire & Sélection pour Incubation)

1. **Ingestion & Cadrage** :
   - 11 Maquettes SVG analysées.
   - 1 transcription d'atelier de 1 583 lignes (`Atelier - Incubations et ventes - Boires.md`).
   - 4 captures de notes de grooming annotées.
2. **Ce que l'IA produit en direct** :
   - Cita les propos d'Antoine Prince aux **lignes 301–324** pour justifier le tri par œuf le plus ancien.
   - Identifia l'annotation visuelle de la note **`10_15_35.jpg`** imposant l'ajout de la colonne *Lot*.
   - Posa la question chirurgicale sur le comportement au-delà de 3 buggies.
3. **Résultat en direct avec le Designer UX** :
   - Clarification immédiate en temps réel sur la planification en 2 étapes voulue par le client (Michel), permettant de geler proprement le FE et de débloquer le BE sans aucun gaspillage d'effort !

---

# 🏗️ Slide 5 : L'Architecture Technique Sous le Capot (ADR-0326)

Le système de preuves mLoop repose sur une architecture découplée en **4 Couches étanches** :

```mermaid
flowchart LR
    subgraph Run["Temps Réel & Session"]
        C1a["Couche 1a : Console CLI<br/>(Log direct [FACT-SEARCH])"]
        C1b["Couche 1b : Restitution Visuelle<br/>(Dossier de Preuves en séance)"]
    end

    subgraph Persist["Persistance & Audit Découplé"]
        C2["Couche 2 : EvidencePack JSON<br/>(memory/evidence/US_evidence.json)"]
        C3["Couche 3 : Journal d'Audit JSONL<br/>(memory/fact_search_log.jsonl)"]
    end

    subgraph Clean["Livrable Final Dev-Ready"]
        US["User Story Markdown Pure<br/>- Frontmatter YAML<br/>- Critères & Profil B<br/>- 4 Piliers Gherkin<br/>🚫 ZÉRO bruit/citation IA"]
    end

    Run --> Persist
    Persist -.-> Clean
```

### 🛡️ Le Principe du « Zero-Bruit » (ADR-0319 Universal Dev Handoff) :
* Le dossier de preuves sert à **l'arbitrage pendant le dialogue**.
* Une fois validé, le récit Markdown final est **100% no-code, pur et fonctionnel**, prêt à être consommé par n'importe quel développeur ou agent de build (Cursor, Copilot, Renaud, OpenSpec).

---

# 📈 Slide 6 : Pourquoi l'Équipe « Capote » ? (Bénéfices & ROI)

| Axe d'Évaluation | Avant (IA Standard) | Avec *Grill with Docs* (mLoop) |
| :--- | :--- | :--- |
| **Niveau de Confiance** | Faible (*« Est-ce halluciné ? »*) | **Total** (*Citation + Lignes exactes à l'écran*). |
| **Temps d'Alignement PO** | 3 à 5 allers-retours de clarification | **1 tour unique** avec recommandation claire. |
| **Traçabilité Client** | Diffuse et dispersée | **Inattaquable** (*Adossée aux verbatims et maquettes SSOT*). |
| **Qualité des Récits** | Scores cosmétiques regex | **4 Piliers Gherkin** blindés et prêts pour les tests. |

---

# 🚀 Conclusion & Message Clé pour la Table Ronde

> ### 💬 La Phrase Choc à retenir :
> *« L'IA ne doit pas être un devin complaisant qui vous dit ce que vous voulez entendre. Elle doit être l'auditeur le plus rigoureux de votre projet, qui vous montre la preuve avant d'exiger votre décision. »*

---

### 🛠️ Boîte à Outils Prête à l'Emploi pour les Démos
- **Commande de lancement** : `python src/swarm.py grill --project <nom_projet>`
- **Skill associé** : [`.agents/skills/grill/SKILL.md`](file:///c:/Memory%20Loop/.agents/skills/grill/SKILL.md)
- **ADR de référence** : [`standards/adr-system/0326-fact-search-and-substantive-content-review.md`](file:///c:/Memory%20Loop/standards/adr-system/0326-fact-search-and-substantive-content-review.md)
