# 🏢 Répertoire des Projets Clients (Multi-Projets)

Chaque sous-dossier ici représente un projet client étanche créé via :
```bash
mloop init --role <ba|dev|pm|design> --project <NomDuClient>
```
