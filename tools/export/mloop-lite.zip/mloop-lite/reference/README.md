# 📂 Pylône 1 : Reference (Staging Brut)

Déposez ici tous vos documents bruts non traités :
* Transcriptions d'ateliers (.txt, .vtt)
* Documents Word (.docx), Excel (.xlsx), PowerPoint (.pptx)
* Fichiers PDF et images/scans (.png, .jpg)

Lancez ensuite :
```bash
mloop ingest
```
