# Sprint Backlog - mLoop

## Règle de responsabilité
> 💡 **Règle de responsabilité** (alignée sur STORY_LIFECYCLE_PROTOCOL.md) : 
> - `OPEN` / `DRAFT` ➡️ **⚪ À faire** (Personne ne travaille dessus)
> - `IN_ANALYZE` ➡️ **🤖 IA** (L'agent analyse, pose des questions, rédige)
> - `READY_FOR_GROOMING` / `READY_FOR_DEV` ➡️ **👤 Humain** (Valider, toiletter ou coder)
> - `IN_DEV` ➡️ **🔧 En cours** (Implémentation physique active)
> - `DONE_TESTED` ➡️ **✅ IA** (Implémenté et tests unitaires OK)
> - `SHIPPED` ➡️ **🚀 Livré** (Synchronisé Git + Jira + Artefacts)

---

## Épopée : EPIC-1-CORE-LOOP (Noyau de la Boucle & Contrôle)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-001-BE** | - | Backend | Moteur d'état `LoopState` (Pydantic v2 schemas) | `SHIPPED` | ✅ IA |
| [x] | **MLOOP-002-BE** | - | Backend | Orchestrateur Asymétrique (Routage Système 2 vs Système 1) | `SHIPPED` | ✅ IA |
| [x] | **MLOOP-003-BE** | - | Kernel | Circuit Breaker Financier (Tokens & TTL) | `SHIPPED` | ✅ IA |

---

## Épopée : EPIC-2-HYBRID-MEMORY (Système de Mémoire Hybride)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-010-BE** | - | MCP Server | Serveur MCP `mcp_loop_mem` (Recherche 1-hop) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-011-BE** | - | MCP Server | Standard SEP-2640 (Exposition via `skill://`) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-013-BE** | - | Memory | Démon de Préchargement d'Engrammes (Asynchronous Preloader) | `SHIPPED` | ✅ IA |

---

## Épopée : EPIC-3-SAFETY-GOVERNANCE (Sécurité et Gouvernance)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-020-BE** | - | Safety | Verrou physique `Story Guard` (Middleware d'écriture SCC) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-021-BE** | - | Safety | Linter Sémantique `WikiFix` (Refactoring Modulaire <=300L) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-023-BE** | - | Safety | Optimisation RHO (Génération déterministe & Registre d'Hypothèses) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-024-BE** | - | Safety | Pont de Speculative Drafting (Confidence Gate) | `SHIPPED` | ✅ IA |
| [x] | **MLOOP-025-BE** | - | Safety | Suite d'Évaluation de Gouvernance (AOEP-v0) | `SHIPPED` | ✅ IA |
| [x] | **MLOOP-026-BE** | - | Safety | Infrastructure de Désapprentissage Agentique (Agentic Unlearning) | `SHIPPED` | ✅ IA |

---

## Épopée : EPIC-4-SKILL-ECOSYSTEM (Écosystème de Compétences)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-030-BE** | - | Skill | Protocole `Grill with Docs` (Question unique + recommandation) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-031-BE** | - | Skill | Compétence `Wayfinder` (Exploration multi-chemins & DAG) | `DONE_TESTED` | ✅ IA |

---

## Épopée : EPIC-5-INGESTION-OFFICE (Ingestion & Bureautique)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-040-BE** | - | Ingest | Pipeline `MarkItDown` (Conversion locale sandboxed) | `DONE_TESTED` | ✅ IA |

---

## Épopée : EPIC-6-OKF-ENCLAVE (Open Knowledge Format & Enclave gVisor)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-050-BE** | - | Ingest/Skill | Compilateur OKF & Skill Factory (Entités typées) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-051-BE** | - | Memory | Recherche Hybride Tri-Flux (BM25 + Vector + Graphify) & Score de Confiance | `DONE_TESTED` | ✅ IA |

---

## Épopée : EPIC-7-AGENTIC-OBSERVABILITY (Observabilité Agentique Souveraine & Cockpit 2.0) [IN_PROGRESS]

> ▶️ **Reprise Post-Harnais (ADR-0381)** : Épopée reprise sous la protection du harnais déterministe EPIC-8. Récits `MLOOP-070-BE`, `071-BE`, `072-BE` et `073-FE` scellés en `DONE_TESTED`. `MLOOP-074-FULL` en cours de développement physique via le harnais Phase 3.

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-070-BE** | - | Safety/Kernel | Disjoncteur Anti-Boucle Ping-Pong Guard (3 Handoffs Max) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-071-BE** | - | Engine/Artifacts | Intercepteur Boundary Tracing & Auto-Offload OpaqueArtifactBus | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-072-BE** | - | Core/Telemetry | Normalisation Locale des Événements JSONL OpenInference / OTel GenAI | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-073-FE** | - | Cockpit/UI | Jauge Contextuelle Dynamique 3-Zones par Session (Header Bento Grid) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-074-FULL** | - | Swarm/DreamRSI | Runway de Handoffs Multi-Agents & Trajectory Diff Viewer (Dream RSI) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-075-FULL** | - | Cockpit/Data | Explorateur Interactif Knowledge Graph (Graphify) & Base SQLite Souveraine | `DONE_TESTED` | ✅ IA |

---

## Épopée : EPIC-8-BUILD-HARNESS-GOVERNANCE (Harnais Déterministe & Gouvernance Phase 3)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-080-BE** | - | Core/Linter | Linter Statique Déterministe AST `code-check` CLI (Règles ADR-0202 & ADR-0369) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-081-BE** | - | Pipelines/Tournament | Moteur de Tournoi de Code Multi-Draft & Matrice d'Arbitrage Pareto ($S_{\text{pareto}}$) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-082-BE** | - | Core/TDD | Protocole TDD Red-Green Enforcement & Verrouillage Cryptographique Gate 3 | `DONE_TESTED` | ✅ IA |

---

## Épopée : EPIC-9-STAGE4-DETERMINISTIC-VALIDATION (Harnais Déterministe de Phase 4 & Certification QA)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-090-BE** | - | Pipelines/QA | Moteur de Certification QA Sprint & Triangulation 4 Piliers Gherkin | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-091-BE** | - | Pipelines/NLI | Contradiction Engine NLI & Verification Leakage Gate (ADR-0326 & ADR-0354) | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-092-BE** | - | Core/Lifecycle | Verrous Bloquants de Gate 4 & Gouvernance Opposable de Recette QA (ADR-0383) | `DONE_TESTED` | ✅ IA |

---

## Épopée : EPIC-12-PHASE4-HARDENING (Renforcement & Blinder Phase 4 — Zero Blindspot)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [x] | **MLOOP-120-BE** | - | Standards/ADR | Fondations Normatives & Spécification Phase 4 : ADR-0383, Checklist & Parité | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-122-BE** | - | Pipelines/Evidence | Traçabilité & Preuves Phase 4 : Lien QA → Lifecycle → Handoff | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-123-BE** | - | Core/Safety | Garde-Fous Automatiques Phase 4 : Vibe-Check & Zombie Reap | `DONE_TESTED` | ✅ IA |
| [x] | **MLOOP-124-BE** | - | Observabilité | Observabilité & Clôture Phase 4 : Logs Structurés & Rapport | `DONE_TESTED` | ✅ IA |

---

## Épopée : EPIC-10-SOVEREIGN-EXCELLENCE (Excellence Souveraine, Rénovation Modulaire & Temps Réel)

| État | Récit            | Clé Jira | Composant         | Titre                                                                                              | Statut        | Responsable |
| :--: | :--------------- | :------: | :---------------- | :------------------------------------------------------------------------------------------------- | :------------ | :---------- |
| [x]  | **MLOOP-100-BE** |    -     | Pipelines/Jira    | Découpage Modulaire du Moteur de Synchronisation Jira (ADR-0202 <=300L)                            | `DONE_TESTED` | ✅ IA       |
| [x]  | **MLOOP-101-BE** |    -     | Utils/Core        | Rénovation Modulaire du Résolveur Lexical et Grand Livre de Jetons                                 | `DONE_TESTED` | ✅ IA        |
| [x]  | **MLOOP-102-BE** |    -     | Memory/Vector     | Consolidation du Flux Vectoriel RHO et Recherche Hybride sur Embeddings Locaux (mxbai-embed-large) | `DONE_TESTED`  | ✅ IA       |
| [x]  | **MLOOP-103-BE** |    -     | Bridges/MCP       | Transport MCP Réseau et Diffusion Événementielle SSE                                               | `DONE_TESTED` | ✅ IA       |
| [x]  | **MLOOP-104-FE** |    -     | Cockpit/UI        | Visualiseur Interactif Force-Directed Graph dans le Cockpit Web                                    | `DONE_TESTED` | ✅ IA       |
| [x]  | **MLOOP-105-BE** |    -     | Core/Security     | Garde-Fou Cryptographique et Hook Pre-Commit Déterministe                                          | `DONE_TESTED` | ✅ IA        |
| [x] | **MLOOP-106-BE** | - | Commands/Handlers | Découpage Modulaire des Handlers CLI (ADR-0202 <=300L) | `DONE_TESTED` | ✅ IA |
| [ ]  | **MLOOP-107-BE** |    -     | Pipelines/Focus   | Correction du Verrou d'Attention Focus (Persistance Frontmatter et Verdict)                        | `DRAFT`       | 🤖 IA       |
| [ ]  | **MLOOP-108-BE** |    -     | Framework/CLI     | Fiabilisation du Harnais E2E Boot-Sequence et Alignement de la Clé LiteLLM Metro                   | `DRAFT`       | 🤖 IA Grill |
| [ ]  | **MLOOP-109-BE** |    -     | Core/Herdr        | Découpage Modulaire de herdr_adapter.py & Alignement RULE-AST-03 (Popen)                           | `DRAFT`       | 🤖 IA       |

---

## Épopée : EPIC-11-ERROR-OBSERVABILITY (Persistance & Gouvernance des Logs d'Erreurs)

| État | Récit | Clé Jira | Composant | Titre | Statut | Responsable |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- |
| [ ] | **MLOOP-110-BE** | - | Utils/Logger | Persistance Rotative des Journaux d'Erreurs du Moteur de Logging mLoop | `READY_FOR_DEV` | 👤 Humain |

---

## 🗄️ Récits Archivés & Dépréciés (TOMBSTONE Archive)
> *Consulter le registre détaillé des motifs d'arbitrage dans [`memory/archive/tombstone_stories.md`](../memory/archive/tombstone_stories.md).*

| État | Récit | Épopée d'Origine | Composant | Titre | Statut | Décision d'Arbitrage |
| :---: | :--- | :--- | :---: | :--- | :--- | :--- |
| [-] | **MLOOP-012-BE** | EPIC-2-HYBRID-MEMORY | Memory | Compression MLA KV Cache | `TOMBSTONE` | Remplacé par OpaqueArtifactBus & Compaction contextuelle |
| [-] | **MLOOP-022-BE** | EPIC-3-SAFETY-GOVERNANCE | Safety | Audit Intentionnel `J-Lens` | `TOMBSTONE` | Remplacé par Invariants NLI & Assertions déterministes EPIC-9 |
| [-] | **MLOOP-032-BE** | EPIC-4-SKILL-ECOSYSTEM | Skill | `Skill Auto-Creator` | `TOMBSTONE` | Élagué — Risque de sécurité HITL & règle Zero-Bloat ADR-0362 |
| [-] | **MLOOP-041-BE** | EPIC-5-INGESTION-OFFICE | Skill | Bridge `OfficeCLI` | `TOMBSTONE` | Élagué — Périmètre SSOT 100% Markdown (couvert par MarkItDown) |
| [-] | **MLOOP-042-FE** | EPIC-5-INGESTION-OFFICE | Frontend | Visualiseur de Rendu HTML Office | `TOMBSTONE` | Élagué par transitivité avec MLOOP-041-BE |